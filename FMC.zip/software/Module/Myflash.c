#include"Myflash.h"

#define  Left_Motor_Erase			255



void Save_Left_motor()
{
	FLASH_EraseSector(Left_Motor_Erase);
		
	
					



}







