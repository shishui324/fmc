#ifndef _MYFLASH__H
#define _MYFLASH__H

#include "headfile.h"
#include "KEA128_flash.h"





#endif


