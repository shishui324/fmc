
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'FuckMyCar' 
 * Target:  'FMC' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "SKEAZ1284.h"

#define RTE_USB_Device_ADC_0            /* USB Device ADC instance 0 */

#endif /* RTE_COMPONENTS_H */
