#ifndef __DEBUG_H
#define __DEBUG_H



void vcan_sendware(void *wareaddr, uint32_t waresize);





#endif


