#ifndef _FUZZY_H_
#define _FUZZY_H_

#include "chip.h"







#endif	//fuzzy.h

