
#include "struct.h"
#include "track.h"
#include "sensor.h"

void Track_Arbiter(void)
{
	
	

	
	
							//200
	if(abs(Sensor.sub_25[0])>35&&(Sensor.sum_16_34>250))	//   �� �� ��
{
//		circle_in = 1;

							Bell_Cry(300,300);
		
//		circle_flag=false;
//		circle_counter=0;
//		if(!(circle_left_flag)&&!(circle_right_flag))
//		{
//		if(sensor->once_uni_ad[2]>sensor->once_uni_ad[5])
//			circle_left_flag = 1;
//		else
//			circle_right_flag = 1;
//		}
	}
//    else
//		{
//		circle_left_flag = 0;
//		circle_in = 0;
//		circle_right_flag = 0;
//		}
	

		
		
		
			
	
	
}

